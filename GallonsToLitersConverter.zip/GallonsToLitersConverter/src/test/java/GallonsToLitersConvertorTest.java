import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.Test;

public class GallonsToLitersConvertorTest {

    // BVA Tests
    @Test
    public void testConversionBoundaryLow() {
        // Test case for boundary value of gallons (lower limit)
        // Reason: To check the function's behavior at the minimum valid gallons (0 gallons)
        double litersPerDay = GallonsToLitersConverter.convertGallonsToLiters(0);
        assertEquals(0, litersPerDay, 0.01);
    }

    @Test
    public void testConversionBoundaryHigh() {
        // Test case for boundary value of gallons (upper limit)
        // Reason: To check the function's behavior at a high value (e.g., 10000 gallons)
        double litersPerDay = GallonsToLitersConverter.convertGallonsToLiters(10000);
        assertEquals(37854.1, litersPerDay, 0.01);
    }

    @Test
    public void testConversionJustAboveZero() {
        // Test case for just above the lower boundary (e.g., 0.01 gallons)
        // Reason: To check the function's accuracy for very small values
        double litersPerDay = GallonsToLitersConverter.convertGallonsToLiters(0.01);
        assertEquals(0.0378541, litersPerDay, 0.01);
    }

    @Test
    public void testConversionJustBelowHigh() {
        // Test case for just below a high value (e.g., 9999.99 gallons)
        // Reason: To check the function's accuracy for values just below a high boundary. Adjusting delta(third parameter in 'assertEquals') to a slightly larger value for the precision issue 
        double litersPerDay = GallonsToLitersConverter.convertGallonsToLiters(9999.99);
        assertEquals(37853.9624359, litersPerDay, 0.1);
    }

    // EP Tests
    @Test
    public void testConversionSmallValue() {
        // Equivalence partition: Small gallons value
        // Reason: To check the function's correctness for small values
        double litersPerDay = GallonsToLitersConverter.convertGallonsToLiters(1);
        assertEquals(3.78541, litersPerDay, 0.01);
    }

    @Test
    public void testConversionMediumValue() {
        // Equivalence partition: Medium gallons value
        // Reason: To check the function's correctness for medium values
        double litersPerDay = GallonsToLitersConverter.convertGallonsToLiters(50);
        assertEquals(189.2705, litersPerDay, 0.01);
    }

    @Test
    public void testConversionLargeValue() {
        // Equivalence partition: Large gallons value
        // Reason: To check the function's correctness for large values
        double litersPerDay = GallonsToLitersConverter.convertGallonsToLiters(500);
        assertEquals(1892.705, litersPerDay, 0.01);
    }

    @Test
    public void testConversionVeryLargeValue() {
        // Equivalence partition: Very large gallons value
        // Reason: To check the function's correctness for very large values
        double litersPerDay = GallonsToLitersConverter.convertGallonsToLiters(1000);
        assertEquals(3785.41, litersPerDay, 0.01);
    }
    // We add the below two tests to make sure class declaration line and main method are covered.
    @Test
    public void testMainMethod() {
        // Redirect standard output to a ByteArrayOutputStream so we can capture the output of the main method
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Call the main method
        String[] args = {};
        GallonsToLitersConverter.main(args);

        // Extract the numerical value from the output
        String output = outContent.toString();
        String[] parts = output.split(" = ");
        String[] litersParts = parts[1].split(" ");
        double litersValue = Double.parseDouble(litersParts[0]);

        // Check that the numerical value is what we expect, allowing for a small delta
        assertEquals(378.541, litersValue, 0.001);

        // Reset standard output to its original state
        System.setOut(System.out);
    }

    @Test
    public void testGallonsToLitersConverterInstantiation() {
        // Test case to instantiate the GallonsToLitersConverter class
        // Reason: This test is added to ensure 100% coverage by covering the class declaration line.
        // It verifies that the class can be instantiated, even though it's not necessary for static methods.
        GallonsToLitersConverter converter = new GallonsToLitersConverter();
        assertNotNull(converter);
    }


}
