public class GallonsToLitersConverter {

    public static double convertGallonsToLiters(double gallonsPerDay) {
        return gallonsPerDay * 3.78541;
    }

    public static void main(String[] args) {
        double gallonsPerDay = 100; // US gallons
        double litersPerDay = convertGallonsToLiters(gallonsPerDay);
        System.out.println(gallonsPerDay + " US gallons per day = " + litersPerDay + " liters per day");
    }
}
