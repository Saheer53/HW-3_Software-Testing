public class BMICalculator {

    public static double calculateBMI(double heightInMeters, double weightInKilograms) {
        return weightInKilograms / (heightInMeters * heightInMeters);
    }

    public static void main(String[] args) {
        double height = 1.75; // meters
        double weight = 70; // kilograms
        double bmi = calculateBMI(height, weight);
        System.out.println("BMI: " + bmi);
    }
}
