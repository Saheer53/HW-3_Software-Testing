import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.Test;

public class BMICalculatorTest {

	 // BVA Tests
    @Test
    public void testBMIBoundaryLowHeight() {
        double bmi = BMICalculator.calculateBMI(0.5, 50); // Height at lower boundary (0.5 meters)
        assertEquals(200, bmi, 0.01);
    }

    @Test
    public void testBMIBoundaryHighHeight() {
        double bmi = BMICalculator.calculateBMI(2.5, 50); // Height at upper boundary (2.5 meters)
        assertEquals(8, bmi, 0.01);
    }

    @Test
    public void testBMIBoundaryLowWeight() {
        double bmi = BMICalculator.calculateBMI(1.5, 10); // Weight at lower boundary (10 kilograms)
        assertEquals(4.44, bmi, 0.01);
    }

    @Test
    public void testBMIBoundaryHighWeight() {
        double bmi = BMICalculator.calculateBMI(1.5, 200); // Weight at upper boundary (200 kilograms)
        assertEquals(88.89, bmi, 0.01);
    }

    // EP Tests
    @Test
    public void testBMIUnderweight() {
        double bmi = BMICalculator.calculateBMI(1.8, 50); // Expected BMI is 15.43
        assertEquals(15.43, bmi, 0.01);
    }

    @Test
    public void testBMINormalWeight() {
        double bmi = BMICalculator.calculateBMI(1.8, 70); // Expected BMI is 21.60
        assertEquals(21.60, bmi, 0.01);
    }

    @Test
    public void testBMIOverweight() {
        double bmi = BMICalculator.calculateBMI(1.8, 90); // Expected BMI is 27.78
        assertEquals(27.78, bmi, 0.01);
    }

    @Test
    public void testBMIObese() {
        double bmi = BMICalculator.calculateBMI(1.8, 110); // Expected BMI is 33.95
        assertEquals(33.95, bmi, 0.01);
    }
    // We add the below two tests to make sure class declaration line and main method are covered.
    @Test
    public void testMainMethod() {
        // Redirect standard output to a ByteArrayOutputStream so we can capture the output of the main method
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        // Call the main method
        String[] args = {"1.75", "70"};
        BMICalculator.main(args);

        // Check that the output is what we expect
        assertEquals("BMI: 22.857142857142858\n", outContent.toString());

        // Reset standard output to its original state
        System.setOut(System.out);
    }
    @Test
    public void testBMICalculatorInstantiation() {
        BMICalculator calculator = new BMICalculator();
        assertNotNull(calculator);
    }


}