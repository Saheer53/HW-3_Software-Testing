public class ParallelogramPerimeter {

    public static double calculatePerimeter(double base, double height) {
        return 2 * (base + height);
    }

    public static void main(String[] args) {
        double base = 10; // units
        double height = 5; // units
        double perimeter = calculatePerimeter(base, height);
        System.out.println("Perimeter of the parallelogram: " + perimeter);
    }
}
