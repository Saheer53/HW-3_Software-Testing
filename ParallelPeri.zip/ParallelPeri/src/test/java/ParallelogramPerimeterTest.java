import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.Test;


public class ParallelogramPerimeterTest{

// BVA Tests
@Test
public void testPerimeterBoundaryLowBase() {
    // Test for the lower boundary of base
    double perimeter = ParallelogramPerimeter.calculatePerimeter(0.1, 5);
    assertEquals(10.2, perimeter, 0.01);
}

@Test
public void testPerimeterBoundaryHighBase() {
    // Test for the upper boundary of base
    double perimeter = ParallelogramPerimeter.calculatePerimeter(100, 5);
    assertEquals(210, perimeter, 0.01);
}

@Test
public void testPerimeterBoundaryLowHeight() {
    // Test for the lower boundary of height
    double perimeter = ParallelogramPerimeter.calculatePerimeter(5, 0.1);
    assertEquals(10.2, perimeter, 0.01);
}

@Test
public void testPerimeterBoundaryHighHeight() {
    // Test for the upper boundary of height
    double perimeter = ParallelogramPerimeter.calculatePerimeter(5, 100);
    assertEquals(210, perimeter, 0.01);
}

// EP Tests
@Test
public void testPerimeterSmallValues() {
    // Test for small base and height values
    double perimeter = ParallelogramPerimeter.calculatePerimeter(2, 3);
    assertEquals(10, perimeter, 0.01);
}

@Test
public void testPerimeterMediumValues() {
    // Test for medium base and height values
    double perimeter = ParallelogramPerimeter.calculatePerimeter(10, 15);
    assertEquals(50, perimeter, 0.01);
}

@Test
public void testPerimeterLargeValues() {
    // Test for large base and height values
    double perimeter = ParallelogramPerimeter.calculatePerimeter(50, 70);
    assertEquals(240, perimeter, 0.01);
}

@Test
public void testPerimeterEqualBaseAndHeight() {
    // Test for equal base and height values
    double perimeter = ParallelogramPerimeter.calculatePerimeter(10, 10);
    assertEquals(40, perimeter, 0.01);
}
// We add the below two tests to make sure class declaration line and main method are covered.
@Test
public void testParallelogramInstantiation() {
    // Test case to instantiate the Parallelogram class
    // Reason: This test is added to ensure 100% coverage by covering the class declaration line.
    // It verifies that the class can be instantiated, even though it's not necessary for static methods.
	ParallelogramPerimeter parallelogram = new ParallelogramPerimeter();
    assertNotNull(parallelogram);
}
@Test
public void testMainMethod() {
    // Redirect standard output to a ByteArrayOutputStream so we can capture the output of the main method
    ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    System.setOut(new PrintStream(outContent));

    // Call the main method
    String[] args = {};
    ParallelogramPerimeter.main(args);

    // Check that the output is what we expect
    // Adjust the expected output based on the base and height values used in your Parallelogram main method
    assertEquals("Perimeter of the parallelogram: 30.0\n", outContent.toString());

    // Reset standard output to its original state
    System.setOut(System.out);
}

}